geektool-scripts
================

My scripts for Geektool. Some of them are mine, others are from what I found googling a litte bit and some others are work in-progess. If you put all (or the most of them) togheter, you end up with a desktop like this:

<img src="http://blogs.fcallem.net/bitio/wp-content/uploads/2013/02/geektool-desktop.png" width="100%"/>

The complete guide on how to set up your desktop to look like this one is [here](http://bit.ly/Wu4O02)