My Geeklets
===

A set of Geeklets for use with [GeekTool](http://projects.tynsoe.org/en/geektool/). Also
available vie the AppStore.

See [http://www.macosxtips.co.uk/geeklets/](http://www.macosxtips.co.uk/geeklets/) for
more Geeklets.

Install background_shade.glet first then everything else.
--

* date.glet: (Day of the Week) (Month) (Day of the Month), (Year)
* ethernet_label.glet & ethernet_link.glet: display IP or 'Disconnected'
* wireless_label.glet & wireless_link.glet: display IP or 'Disconnected'
* background_shade.glet: background for the Geeklets
* disk_capacity_label.glet & disk_usage.glet: percentage of disk space used
* top.glet: display top processe mem% and cpu% refreshed every 15secs

Make sure the files are opened with the GeekTool Helper application.